#HerHealthMate Chat Bot

An AI Chat Bot that provides assistance to females regarding Gynecology related issues.

#replace api_key by your api token from openai.com